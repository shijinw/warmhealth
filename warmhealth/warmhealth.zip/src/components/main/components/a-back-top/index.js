import ABackTop from './index.vue'
export default ABackTop
