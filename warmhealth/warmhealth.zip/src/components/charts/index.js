import ChartPie from './pie.vue'
import ChartBar from './bar.vue'
export { ChartPie, ChartBar }
