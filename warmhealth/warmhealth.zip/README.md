<h1>
医护小程序后台管理系统
    <h3>本项目依赖于 nodejs vuejs iViewUI webPack less es6 npm...</h3>
</h1>

## Introduction

BS Admin is a front-end management background integration solution. It based on [Vue.js](https://github.com/vuejs/vue) and use the UI Toolkit [iView](https://github.com/iview/iview).


- [Vue](https://cn.vuejs.org/)
- [iView](https://www.iviewui.com/)
- [Author Repository](https://gitee.com/blueCodes_admin/ds/)


## Getting started
```bush
# clone the project
git clone xxxxxxx.git

// install dependencies
npm install

// develop
npm run dev
```

## Build
```bush
npm run build
```

## 联系方式


<div align="center">
<img src="https://blueoss.oss-cn-beijing.aliyuncs.com/imgs/WechatIMG4660.png" width=200 height=200 />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="https://blueoss.oss-cn-beijing.aliyuncs.com/imgs/WechatIMG4662.png" width=200 height=200 />
</div>
